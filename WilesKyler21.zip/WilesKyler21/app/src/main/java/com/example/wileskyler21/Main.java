package com.example.wileskyler21;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.widget.EditText;

public class Main extends SQLiteOpenHelper {
    private EditText username;
    private EditText password;
    
    
    private static final String loginDatabase = "loginDatabase";
    private static final int VERSION =1;

    public Main(Context context) {
        super(context, loginDatabase, null, VERSION);

    }
    private static final class logTable{
        private static final String USER = "ADMIN";
        private static final String PASS = "ADMIN";
        private static final String  ITEMS = "items";

    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(String.format("creating%s", logTable.ITEMS));

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(String.format("updating%s", logTable.ITEMS));
        onCreate(db);


    }
    protected void onCreate(Bundle savedInstanceState){

        setContentView(R.layout.activity_main);
        username = username.findViewById(R.id.username);
        password = password.findViewById(R.id.password);
    }

    private void setContentView(int activityMain) {
    }
    private void loggingIn(){
        username.setText(username.getText().toString());
        password.setText(username.getText().toString());

        if(username == username || password ==password) {
           return;
        }
        else{

        }
    }


}
